# Notebook model extraction audit

- Source notebook: `Final_AFCNet(Kaggle).ipynb` (provided source; not modified).
- Primary AFCNet model: code cell 11. Components: `ChannelAttention`, `SpatialAttention`, `CBAM`, `GlobalLocalFusion`, `RDRH`, `AFCNet`.
- The primary model inserts CBAM after MobileNetV3-Large feature indices 3 and 9, and after the final feature map; applies GLF, global average pooling, then RDRH.
- The notebook has a separate fallback AFCNet in cell 12 and a later prediction redefinition in cell 17. Those use a different architecture and should not be conflated with the primary model.
- The source notebook's spatial attention returns `x * sigmoid(x)` after `x` has been replaced by a one-channel convolution output. This causes the attention block to return one channel, not the original number of feature channels. The repository version preserves the original input feature map and applies the one-channel spatial gate to it.
- The notebook's dataset class independently sorts images and labels and pairs by index; this repository pairs by file identity instead. The notebook counts all lines; this repository counts non-empty lines. Verify annotation schema before interpreting line count as vehicle count.
- Notebook cell 13 calculates epoch metrics from training-batch predictions. These are training metrics, not held-out test metrics.
