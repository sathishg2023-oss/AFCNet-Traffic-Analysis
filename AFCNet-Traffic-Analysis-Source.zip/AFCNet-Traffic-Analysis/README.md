# AFCNet — Attention Fusion Counting Network

Research repository for frame-level vehicle counting on UA-DETRAC. The model implementation follows the primary AFCNet definition in `Final_AFCNet(Kaggle).ipynb`, Cell 11: MobileNetV3-Large, hierarchical CBAM, Global–Local Fusion (GLF), and Residual Dense Regression Head (RDRH).

## Important implementation and reproducibility notes

- The notebook's primary `SpatialAttention.forward()` overwrites its input tensor and returns a one-channel tensor. That cannot preserve the feature-channel shape expected by the next MobileNet layer. `src/afcnet/model.py` corrects this by applying the spatial map to the original feature map. This is a shape-preserving CBAM operation; it is documented rather than hidden.
- A later notebook cell defines a different fallback AFCNet (MobileNetV3 features + channel attention + MLP). It is **not** the primary Cell 11 model and is not used here.
- Notebook dataset labels are calculated as the number of lines in each text file. This repository counts **non-empty** lines. Confirm that each non-empty annotation line corresponds to exactly one vehicle before treating these as ground-truth counts.
- The notebook's training loop reports metrics over training batches. Those values are not held-out test metrics. Use validation and a separate test split for publishable generalization claims.
- The default split is contiguous after sorting, which is preferable to random frame splitting for ordered video sequences. If multiple video sequences are stored together, split by video/sequence ID instead; do not allow neighboring frames from one sequence to leak across train and test.
- Image preprocessing uses 224×224 resizing and ImageNet normalization. Training-only augmentation follows the notebook's horizontal flip, rotation, and color jitter. Validation/evaluation transforms are deterministic.

## Setup

Python 3.10+ recommended. Install a PyTorch/torchvision build appropriate for your CPU or CUDA setup, then:

```bash
pip install -r requirements.txt
pip install -e .
```

## 1. Inspect image/annotation pairing

```bash
python scripts/inspect_dataset.py --images /path/to/images --labels /path/to/annotations
```

Pairing is performed by relative path/stem where possible, not by independently sorting image and label lists. Ambiguous duplicate stems cause an explicit error.

## 2. Train

```bash
python scripts/train.py   --images /path/to/train/images   --labels /path/to/train/annotations   --output outputs/afcnet   --epochs 20 --batch-size 8 --lr 1e-4 --split contiguous --amp
```

`--amp` enables CUDA mixed precision. `best.pt` is selected using validation MAE; `last.pt`, `history.json`, and `config.json` are also saved. Pretrained MobileNetV3 weights are used by default; use `--no-pretrained` for offline initialization without downloading weights.

## 3. Evaluate a checkpoint

Use a **held-out test set**, not the training data:

```bash
python scripts/evaluate.py   --images /path/to/test/images   --labels /path/to/test/annotations   --checkpoint outputs/afcnet/best.pt   --output outputs/test_evaluation
```

Outputs include frame-level `predictions.csv` and `metrics.json` with MAE, MSE, RMSE, and sample count.

## Architecture

`AFCNet.forward()` returns a scalar predicted count for each input image. The density/severity labels shown elsewhere in the research notebook are post-processing thresholds, not independent neural-network output heads in this model. The separate SFENet/scene-change notebook experiments are not integrated into this AFCNet counting model yet.

## Test model shape

```bash
pytest -q
```

## Citation and results

Do not copy reported results from notebook training logs into a paper as test results without reproducing evaluation on a held-out split. Record dataset version, exact video/frame split, random seed, GPU, PyTorch/torchvision versions, checkpoint, batch size, and timing protocol. No performance numbers are asserted by this repository until you run it on your data.
